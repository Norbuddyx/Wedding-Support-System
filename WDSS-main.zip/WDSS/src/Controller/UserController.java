/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Models.Users;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import DBconnector.DBConnection;
import java.sql.ResultSet;

public class UserController {
    // 1️⃣ Register user
    public boolean registerUser(Users user) {
        String sql = "INSERT INTO users(full_name, email, username, password, role) VALUES (?, ?, ?, ?,'CLIENT')";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getFullName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getUsername());
            ps.setString(4, user.getPassword());

            int rowsInserted = ps.executeUpdate();
            return rowsInserted > 0; // return true if inserted

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 2️⃣ Check for duplicate email or username
    public boolean checkDuplicate(String email, String username) {
        boolean exists = false;
        String sql = "SELECT * FROM users WHERE email = ? OR username = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, username);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                exists = true; // email or username already exists
            }

            rs.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exists;
    }

    // 3️⃣ Convert / encrypt password
    public String convert(String input, String[] keyMap, String[] refMap) {
        StringBuilder result = new StringBuilder();
        for (char c : input.toCharArray()) {
            int index = -1;
            for (int i = 0; i < refMap.length; i++) {
                if (refMap[i].charAt(0) == c) {
                    index = i;
                    break;
                }
            }
            result.append(index != -1 ? keyMap[index] : c);
        }
        return result.toString();
    }

    // 4️⃣ Verify duplicate for older code (optional, can use checkDuplicate instead)
    public boolean verify(String email, String username) { 
        boolean duplicate = false;
        String sql = "SELECT * FROM users"; 
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                if (email.equals(rs.getString("email")) || username.equals(rs.getString("username"))) {
                    duplicate = true;
                    break;
                }
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return duplicate;
    }
    
    
}

       
   
