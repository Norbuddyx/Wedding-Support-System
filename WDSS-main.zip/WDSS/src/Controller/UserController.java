/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Models.Users;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import DBconnector.DBConnection;
import java.sql.ResultSet;

public class UserController {
    // 1️⃣ Register user
    public boolean registerUser(Users user) {
        String sql = "INSERT INTO users(full_name, email, username, password) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getFullName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getUsername());
            ps.setString(4, user.getPassword());

            int rowsInserted = ps.executeUpdate();
            return rowsInserted > 0; // return true if inserted

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 2️⃣ Check for duplicate email or username
    public boolean checkDuplicate(String email, String username) {
        boolean exists = false;
        String sql = "SELECT * FROM users WHERE email = ? OR username = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, username);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                exists = true; // email or username already exists
            }

            rs.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exists;
    }

    // 3️⃣ Convert / encrypt password
    public String convert(String password, String[] encryp, String[] smallLetters) {
        int start = 0, end = 1, a;
        String new_word = "";
        for (int i = 0; i < password.length(); i++) {
            a = 0;
            for (String encry : encryp) {
                if (password.substring(start, end).equals(smallLetters[a])) {
                    new_word += encry;
                }
                a++;
            }
            start++;
            end++;
        }
        return new_word;
    }

    // 4️⃣ Verify duplicate for older code (optional, can use checkDuplicate instead)
    public boolean verify(String email, String username) { 
        boolean duplicate = false;
        String sql = "SELECT * FROM users"; 
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                if (email.equals(rs.getString("email")) || username.equals(rs.getString("username"))) {
                    duplicate = true;
                    break;
                }
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return duplicate;
    }
}

       
   
