/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author annie
 */
public class Users {
    private String fullname;
    private String email;
    private String fullAddress;
    private String username;
    private String password;
    private String role;

    public Users(String fullname, String email, String fullAddress, String username, String password, String role) {
        this.fullname = fullname;
        this.email= email;
        this.fullAddress = fullAddress;
        this.username = username;
        this.password = password;
        this.role = role;
    }

 
    public String getFullName() { return fullname; }
    public String getEmail() { return email; }
    public String getFullAddress() { return fullAddress; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getrole() { return role; }

}
