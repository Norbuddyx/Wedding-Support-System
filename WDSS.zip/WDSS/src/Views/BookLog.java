/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Views;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import DBconnector.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Logger;
import Views.AdminBoard;

public class BookLog extends javax.swing.JFrame {
    
    private static final Logger logger = Logger.getLogger(BookLog.class.getName());
    private static final String[] TABLE_COLUMNS = {"ID", "CLIENT NAME", "BOOKED VENUE","BOOKED CAPACITY", "BOOKED SCHEDULE", "BOOKED LOCATION", "TOTAL PRICE"};;

    public BookLog() {
        initComponents();
        setupTable();
        loadBookingLogs();
        setupActions();
    }

    private void setupTable() {
        DefaultTableModel model = new DefaultTableModel(new Object[][]{}, TABLE_COLUMNS) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        Booking_Logs.setModel(model);

        // hide ID column safely
        if (Booking_Logs.getColumnModel().getColumnCount() > 0) {
            Booking_Logs.removeColumn(Booking_Logs.getColumnModel().getColumn(0));
        }
    }

    private void loadBookingLogs() {
    DefaultTableModel model = (DefaultTableModel) Booking_Logs.getModel();
    model.setRowCount(0);

    String sql = "SELECT b.booking_id, " +
            "COALESCE(u.full_name, b.full_name, 'Unknown') AS booked_by, " +
            "b.venue_type, b.capacity , CONCAT(b.event_date, ' ', b.event_time) AS schedule, " +
            "b.location, b.total_price " +
            "FROM bookings b " +
            "LEFT JOIN users u ON b.user_id = u.user_id " +
            "WHERE b.status != 'CANCELLED' " +
            "ORDER BY b.event_date, b.event_time";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        boolean hasData = true;

        while (rs.next()) {

            hasData = true;

            model.addRow(new Object[] {
                rs.getInt("booking_id"),
                rs.getString("booked_by"),
                rs.getString("venue_type"),
                rs.getInt("capacity"),
                rs.getString("schedule"),
                rs.getString("location"),
                rs.getDouble("total_price")
            });
        }

        if (!hasData) {
            JOptionPane.showMessageDialog(this, "No bookings found in the database.");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error loading bookings: " + e.getMessage());
        e.printStackTrace();
    }
    }

    private void cancelSelectedBooking() {
    int row = Booking_Logs.getSelectedRow();
    if (row == -1) {
        JOptionPane.showMessageDialog(this, "Select a booking to cancel");
        return;
    }

    String reason = InputReason.getText().trim();
    if (reason.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Enter cancellation reason");
        return;
    }

    // Booking ID is in the hidden column 0
    int bookingId = (int) Booking_Logs.getModel().getValueAt(row, 0);

    String sql = "UPDATE bookings SET status='CANCELLED', cancel_reason=? WHERE booking_id=?";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, reason);
        pst.setInt(2, bookingId);
        pst.executeUpdate();

        JOptionPane.showMessageDialog(this, "Booking cancelled successfully!");
        InputReason.setText(""); // clear input
        loadBookingLogs(); // refresh table

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error cancelling booking: " + e.getMessage());
        e.printStackTrace();
        }   
    }

    private void markBookingDone() {
        int row = Booking_Logs.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a booking to mark DONE");
            return;
        }

        int bookingId = (int) Booking_Logs.getModel().getValueAt(row, 0); // hidden ID

        String sql = "UPDATE bookings SET status='DONE' WHERE booking_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, bookingId);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Booking marked DONE");
            loadBookingLogs(); // refresh table

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating booking: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void setupActions() {
        jButton1.addActionListener(e -> cancelSelectedBooking());
        jButton2.addActionListener(e -> markBookingDone());
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        SA_Home2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Booking_Logs = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        InputReason = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 204));

        jPanel2.setBackground(new java.awt.Color(193, 133, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("BOOK LOGS");

        SA_Home2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/homeIcon (1).png"))); // NOI18N
        SA_Home2.setText("jLabel2");
        SA_Home2.setPreferredSize(new java.awt.Dimension(64, 63));
        SA_Home2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SA_Home2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(SA_Home2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(SA_Home2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addContainerGap())
        );

        Booking_Logs.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "CLIENT NAME", "BOOKED VENUE", "BOOKED CAPACITY", "BOOKED SCHEDULE", "BOOKED LOCATION", "TOTAL PRICE"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Booking_Logs);
        if (Booking_Logs.getColumnModel().getColumnCount() > 0) {
            Booking_Logs.getColumnModel().getColumn(0).setResizable(false);
            Booking_Logs.getColumnModel().getColumn(0).setPreferredWidth(1);
            Booking_Logs.getColumnModel().getColumn(1).setResizable(false);
            Booking_Logs.getColumnModel().getColumn(2).setResizable(false);
            Booking_Logs.getColumnModel().getColumn(3).setResizable(false);
            Booking_Logs.getColumnModel().getColumn(4).setResizable(false);
            Booking_Logs.getColumnModel().getColumn(5).setResizable(false);
            Booking_Logs.getColumnModel().getColumn(6).setResizable(false);
        }

        InputReason.setBackground(new java.awt.Color(255, 255, 204));
        InputReason.setColumns(20);
        InputReason.setRows(5);
        InputReason.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 102, 0)));
        jScrollPane2.setViewportView(InputReason);

        jButton1.setBackground(new java.awt.Color(102, 0, 0));
        jButton1.setFont(new java.awt.Font("Serif", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("CANCEL THIS BOOK");
        jButton1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(193, 133, 0));
        jLabel8.setText("REASON TO CANCEL:");

        jButton2.setBackground(new java.awt.Color(0, 102, 102));
        jButton2.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("BOOK DONE!");
        jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(this::jButton2ActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 483, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(60, 60, 60))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1044, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(12, 12, 12))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void SA_Home2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SA_Home2MouseClicked
       AdminBoard AB = new AdminBoard();
       AB.setAdminName(Session.loggedInAdminName);
       AB.setVisible(true);
       this.dispose();
    }//GEN-LAST:event_SA_Home2MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new BookLog().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Booking_Logs;
    private javax.swing.JTextArea InputReason;
    private javax.swing.JLabel SA_Home2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
