/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Views;


import javax.swing.*;
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import DBconnector.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Views.Session;


public class VenueDetails extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VenueDetails.class.getName());
    private int venueId;
    private int venueCapacity;
    private double venuePrice;
    private int currentUserId;
    private String currentUserFullName;

// Constructor
    public VenueDetails(int userId, String fullName) {
    this.currentUserId = userId;
    this.currentUserFullName = fullName;

    initComponents();
    setSize(553, 800);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);

    setupPaxButtons();
    JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(SETTIME, "hh:mm a");
    SETTIME.setEditor(timeEditor);
    
    
    InputBudget.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
    @Override
    public void insertUpdate(javax.swing.event.DocumentEvent e) { updatePaxButtonsBasedOnBudget(); }
    @Override
    public void removeUpdate(javax.swing.event.DocumentEvent e) { updatePaxButtonsBasedOnBudget(); }
    @Override
    public void changedUpdate(javax.swing.event.DocumentEvent e) { updatePaxButtonsBasedOnBudget(); }
    });
    
    }
    
    private void updatePaxButtonsBasedOnBudget() {
    String budgetText = InputBudget.getText().trim();
    if (budgetText.isEmpty()) {
        limitPaxButtons(); // reset to max capacity
        return;
    }

    try {
        double budget = Double.parseDouble(budgetText);

        // Calculate proportion of budget to venue price
        double proportion = budget / venuePrice;
        if (proportion > 1.0) proportion = 1.0; // cannot exceed venue capacity

        // Compute max pax proportionally
        int maxPaxBasedOnBudget = (int) Math.floor(proportion * venueCapacity / 100.0) * 100; 
        // rounds down to nearest 100

        // Enable/disable buttons based on calculated max pax
        Pax100.setEnabled(maxPaxBasedOnBudget >= 100);
        Pax200.setEnabled(maxPaxBasedOnBudget >= 200);
        Pax300.setEnabled(maxPaxBasedOnBudget >= 300);
        Pax400.setEnabled(maxPaxBasedOnBudget >= 400);
        Pax500.setEnabled(maxPaxBasedOnBudget >= 500);
        Pax600.setEnabled(maxPaxBasedOnBudget >= 600);
        Pax700.setEnabled(maxPaxBasedOnBudget >= 700);
        Pax800.setEnabled(maxPaxBasedOnBudget >= 800);

    } catch (NumberFormatException e) {
        limitPaxButtons(); // invalid input, reset
    }
}

    private void setupPaxButtons() {
        Pax100.addActionListener(e -> SpecifiedPaxCount.setText("100"));
        Pax200.addActionListener(e -> SpecifiedPaxCount.setText("200"));
        Pax300.addActionListener(e -> SpecifiedPaxCount.setText("300"));
        Pax400.addActionListener(e -> SpecifiedPaxCount.setText("400"));
        Pax500.addActionListener(e -> SpecifiedPaxCount.setText("500"));
        Pax600.addActionListener(e -> SpecifiedPaxCount.setText("600"));
        Pax700.addActionListener(e -> SpecifiedPaxCount.setText("700"));
        Pax800.addActionListener(e -> SpecifiedPaxCount.setText("800"));
    }

    public void setVenueDetails(int id, String venueName, int capacity, double price) {
        this.venueId = id;
        this.venueCapacity = capacity;
        this.venuePrice = price;

        Venue_Type.setText(venueName);
        Price_Value.setText(String.format("PRICE: ₱%,.0f", venuePrice));
        limitPaxButtons();
        loadLocations();
    }

    private void limitPaxButtons() {
        Pax100.setEnabled(venueCapacity >= 100);
        Pax200.setEnabled(venueCapacity >= 200);
        Pax300.setEnabled(venueCapacity >= 300);
        Pax400.setEnabled(venueCapacity >= 400);
        Pax500.setEnabled(venueCapacity >= 500);
        Pax600.setEnabled(venueCapacity >= 600);
        Pax700.setEnabled(venueCapacity >= 700);
        Pax800.setEnabled(venueCapacity >= 800);
    }

    private void loadLocations() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT location_name FROM venue_locations WHERE venue_id = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, venueId);
            ResultSet rs = pst.executeQuery();

            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
            while (rs.next()) model.addElement(rs.getString("location_name"));
            LocationAvailabilities.setModel(model);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading locations: " + e.getMessage());
        }
    }
    

    

    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        LocationType = new javax.swing.JLabel();
        Venue_Type = new javax.swing.JLabel();
        Price_Value = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        LocationAvailabilities = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        Pax100 = new javax.swing.JToggleButton();
        Pax200 = new javax.swing.JToggleButton();
        Pax300 = new javax.swing.JToggleButton();
        Pax400 = new javax.swing.JToggleButton();
        Pax500 = new javax.swing.JToggleButton();
        Pax600 = new javax.swing.JToggleButton();
        Pax700 = new javax.swing.JToggleButton();
        Pax800 = new javax.swing.JToggleButton();
        jLabel7 = new javax.swing.JLabel();
        SpecifiedPaxCount = new javax.swing.JTextField();
        InputBudget = new javax.swing.JTextField();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        SETTIME = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 204));

        jPanel2.setBackground(new java.awt.Color(193, 133, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Serif", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 204));
        jLabel1.setText("VENUE DETAILS");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/logoutIcon.png"))); // NOI18N
        jLabel4.setText("jLabel4");
        jLabel4.setPreferredSize(new java.awt.Dimension(58, 53));
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(93, 93, 93))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 13, Short.MAX_VALUE)
                .addComponent(jLabel1))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jLabel2.setBackground(new java.awt.Color(193, 133, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(193, 133, 0));
        jLabel2.setText("SET DATE:");

        jLabel3.setBackground(new java.awt.Color(193, 133, 0));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(193, 133, 0));
        jLabel3.setText("SET PAX:");

        LocationType.setBackground(new java.awt.Color(193, 133, 0));
        LocationType.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        LocationType.setForeground(new java.awt.Color(193, 133, 0));
        LocationType.setText("AVAILABLE LOCATIONS:");

        Venue_Type.setFont(new java.awt.Font("Serif", 1, 24)); // NOI18N
        Venue_Type.setForeground(new java.awt.Color(193, 133, 0));
        Venue_Type.setText("...");

        Price_Value.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        Price_Value.setForeground(new java.awt.Color(193, 133, 0));
        Price_Value.setText("Enter your budget:");

        jButton1.setBackground(new java.awt.Color(193, 133, 0));
        jButton1.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 204));
        jButton1.setText("BOOK THIS");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jLabel5.setFont(new java.awt.Font("Serif", 1, 24)); // NOI18N
        jLabel5.setText("CHOSEN VENUE:");

        LocationAvailabilities.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));

        jLabel6.setBackground(new java.awt.Color(193, 133, 0));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(193, 133, 0));
        jLabel6.setText("SET TIME:");

        Pax100.setBackground(new java.awt.Color(153, 102, 0));
        Pax100.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        Pax100.setForeground(new java.awt.Color(255, 255, 255));
        Pax100.setText("100");
        Pax100.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Pax200.setBackground(new java.awt.Color(153, 102, 0));
        Pax200.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        Pax200.setForeground(new java.awt.Color(255, 255, 255));
        Pax200.setText("200");
        Pax200.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Pax300.setBackground(new java.awt.Color(153, 102, 0));
        Pax300.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        Pax300.setForeground(new java.awt.Color(255, 255, 255));
        Pax300.setText("300");
        Pax300.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Pax400.setBackground(new java.awt.Color(153, 102, 0));
        Pax400.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        Pax400.setForeground(new java.awt.Color(255, 255, 255));
        Pax400.setText("400");
        Pax400.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Pax500.setBackground(new java.awt.Color(153, 102, 0));
        Pax500.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        Pax500.setForeground(new java.awt.Color(255, 255, 255));
        Pax500.setText("500");
        Pax500.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Pax600.setBackground(new java.awt.Color(153, 102, 0));
        Pax600.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        Pax600.setForeground(new java.awt.Color(255, 255, 255));
        Pax600.setText("600");
        Pax600.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Pax700.setBackground(new java.awt.Color(153, 102, 0));
        Pax700.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        Pax700.setForeground(new java.awt.Color(255, 255, 255));
        Pax700.setText("700");
        Pax700.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Pax800.setBackground(new java.awt.Color(153, 102, 0));
        Pax800.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        Pax800.setForeground(new java.awt.Color(255, 255, 255));
        Pax800.setText("800");
        Pax800.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel7.setBackground(new java.awt.Color(193, 133, 0));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(193, 133, 0));
        jLabel7.setText("SET SPECIFIC PAX COUNT:");

        SpecifiedPaxCount.setBackground(new java.awt.Color(255, 255, 204));
        SpecifiedPaxCount.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 102, 0)));

        SETTIME.setModel(new javax.swing.SpinnerDateModel(new java.util.Date(), null, null, java.util.Calendar.HOUR_OF_DAY));
        SETTIME.setValue(new Date());

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Venue_Type))
                        .addGap(132, 132, 132))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Pax100, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Pax200, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Pax300, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Pax400, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Pax500, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Pax600, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Pax700, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Pax800, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SpecifiedPaxCount, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(Price_Value)
                            .addComponent(LocationType)
                            .addComponent(jLabel6)
                            .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(LocationAvailabilities, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(InputBudget, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE))
                            .addComponent(SETTIME, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addGap(4, 4, 4)
                .addComponent(Venue_Type)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(SETTIME, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(LocationType)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LocationAvailabilities, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Price_Value)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(InputBudget, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Pax100, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Pax200, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Pax300, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Pax400, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Pax500, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Pax600, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Pax700, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Pax800, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SpecifiedPaxCount, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
                    .addComponent(jLabel7))
                .addGap(20, 20, 20)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 513, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            String budgetText = InputBudget.getText().trim();
            String paxText = SpecifiedPaxCount.getText().trim();

            if (budgetText.isEmpty() || paxText.isEmpty() || jDateChooser1.getDate() == null) {
                JOptionPane.showMessageDialog(this, "Please complete all fields.");
                return;
            }

            double budget = Double.parseDouble(budgetText);
            int pax = Integer.parseInt(paxText);

            if (budget < 10000) {
                JOptionPane.showMessageDialog(this, "Budget must be at least ₱10,000");
                return;
            }
            if (pax > venueCapacity) {
                JOptionPane.showMessageDialog(this, "Maximum pax for this venue is " + venueCapacity);
                return;
            }

            Date date = jDateChooser1.getDate();
            Date time = (Date) SETTIME.getValue();

            Calendar calDateTime = Calendar.getInstance();
            calDateTime.setTime(date);
            Calendar calTime = Calendar.getInstance();
            calTime.setTime(time);
            calDateTime.set(Calendar.HOUR_OF_DAY, calTime.get(Calendar.HOUR_OF_DAY));
            calDateTime.set(Calendar.MINUTE, calTime.get(Calendar.MINUTE));
            calDateTime.set(Calendar.SECOND, 0);

            Date finalDateTime = calDateTime.getTime();
            if (finalDateTime.before(new Date())) {
                JOptionPane.showMessageDialog(this, "You cannot book a past date or time.");
                return;
            }

            String location = (String) LocationAvailabilities.getSelectedItem();

            String insertSql = "INSERT INTO bookings " +
                   "(user_id, full_name, venue_id, venue_type, capacity, location, event_date, event_time, total_price, status) " +
                   "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement pst = conn.prepareStatement(insertSql)) {

                pst.setInt(1, Session.loggedInUserId);
                pst.setString(2, Session.loggedInUsername);
                pst.setInt(3, venueId);
                pst.setString(4, Venue_Type.getText());
                pst.setInt(5, pax); // <-- add this line
                pst.setString(6, location);
                pst.setDate(7, new java.sql.Date(finalDateTime.getTime()));
                pst.setString(8, new SimpleDateFormat("hh:mm a").format(finalDateTime));
                pst.setDouble(9, budget);
                pst.setString(10, "PENDING");
                pst.executeUpdate(); 
            }

            JOptionPane.showMessageDialog(this, "Booking Successful!");
            VenueBoard vb= new VenueBoard();
            vb.setVisible(true);
            this.dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        VenueBoard vb= new VenueBoard();
        vb.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel4MouseClicked
    private boolean checkIfLoggedInUserIsAdmin(int userId) {
    try (Connection conn = DBConnection.getConnection()) {
        String sql = "SELECT COUNT(*) FROM admins WHERE admin_id = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, userId);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    return true;
                }
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(() -> new VenueBoard().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField InputBudget;
    private javax.swing.JComboBox<String> LocationAvailabilities;
    private javax.swing.JLabel LocationType;
    private javax.swing.JToggleButton Pax100;
    private javax.swing.JToggleButton Pax200;
    private javax.swing.JToggleButton Pax300;
    private javax.swing.JToggleButton Pax400;
    private javax.swing.JToggleButton Pax500;
    private javax.swing.JToggleButton Pax600;
    private javax.swing.JToggleButton Pax700;
    private javax.swing.JToggleButton Pax800;
    private javax.swing.JLabel Price_Value;
    private javax.swing.JSpinner SETTIME;
    private javax.swing.JTextField SpecifiedPaxCount;
    private javax.swing.JLabel Venue_Type;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JButton jButton1;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
