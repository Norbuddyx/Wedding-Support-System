/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Views;

import DBconnector.DBConnection;
import Controller.UserController;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class AccountManage extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(AccountManage.class.getName());
    private byte[] adminImageBytes;
    private File updateAdminImageFile = null;
    private File previewedImageFile = null;
    private File selectedAdminImageFile = null;
    /**
     * Creates new form AccountManage
     */
     public AccountManage() {
        initComponents();
        setSize(1150, 630);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        loadAdminTable();
        loadUserTable();
        loadDeleteTable();
        loadUpdateTable();
    }

    // ------------------ CREATE ADMIN ------------------
    private void createAdmin() {
        String fullname = ADMIN_Fullname.getText().trim();
        String email = ADMIN_email.getText().trim();
        String username = ADMIN_username.getText().trim();
        String password = new String(ADMIN_password.getPassword());
        String role = SELECT_role.getSelectedItem().toString();

        if(role.equals("------SELECT ROLE------") || fullname.isEmpty() || email.isEmpty() || username.isEmpty() || password.isEmpty()){
            JOptionPane.showMessageDialog(this,"Please fill all fields!");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO admins(full_name,email,username,password,role,status) VALUES (?,?,?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1, fullname);
            pst.setString(2, email);
            pst.setString(3, username);
            pst.setString(4, password);
            pst.setString(5, role);
            pst.setString(6, "ACTIVE");

            pst.executeUpdate();
            JOptionPane.showMessageDialog(this,"Admin Created Successfully");
            loadAdminTable();
        } catch(Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    // ------------------ LOAD TABLES ------------------
    private void loadUserTable() {
        DefaultTableModel model = (DefaultTableModel) userTable.getModel();
        model.setRowCount(0);

        try(Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT user_id, full_name, username, password, role FROM users";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getInt("user_id"),
                        rs.getString("full_name"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role")
                });
            }
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    private void loadAdminTable() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);

        try(Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT admin_id, full_name, email, username, role FROM admins";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getInt("admin_id"),
                        rs.getString("full_name"),
                        rs.getString("email"),
                        rs.getString("username"),
                        rs.getString("role")
                });
            }
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    private void loadDeleteTable() {
        try(Connection con = DBConnection.getConnection()) {
            String sql = "SELECT admin_id, full_name, username, password, role FROM admins WHERE role=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1,"ADMIN");
            ResultSet rs = ps.executeQuery();

            DefaultTableModel model = (DefaultTableModel) admintable.getModel();
            model.setRowCount(0);

            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getInt("admin_id"),
                        rs.getString("full_name"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role")
                });
            }
        } catch(Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void loadUpdateTable() {
        DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
        model.setRowCount(0);

        try(Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT admin_id, role, full_name, username, password FROM admins";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getInt("admin_id"),
                        rs.getString("role"),
                        rs.getString("full_name"),
                        rs.getString("username"),
                        rs.getString("password")
                });
            }
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    // ------------------ DELETE ACCOUNT ------------------
    private void deleteAccount() {
        int row = admintable.getSelectedRow();
        if(row == -1){
            JOptionPane.showMessageDialog(this,"Select account first");
            return;
        }

        int id = (int) admintable.getValueAt(row,0);
        String role = admintable.getValueAt(row,4).toString();

        try(Connection con = DBConnection.getConnection()) {
            String sql;
            if(role.equals("ADMIN") || role.equals("SUPER_ADMIN")){
                sql = "DELETE FROM admins WHERE admin_id=?";
            } else {
                sql = "DELETE FROM users WHERE user_id=?";
            }
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1,id);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this,"Account Deleted");
            loadDeleteTable();
        } catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }

    // ------------------ UPDATE ADMIN ------------------
    private void updateAdmin() {
        int row = jTable3.getSelectedRow();
        if(row == -1){
            JOptionPane.showMessageDialog(this,"Select admin first");
            return;
        }

        int id = (int) jTable3.getValueAt(row,0);
        String fullname = UPDATEADMIN_Fullname.getText();
        String username = UPDATEADMIN_username.getText();
        String password = new String(UPDATEADMIN_password.getPassword());
        String role = UPDATE_role.getSelectedItem().toString();

        try(Connection con = DBConnection.getConnection()){
            String sql = "UPDATE admins SET full_name=?, username=?, password=?, role=? WHERE admin_id=?";
            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1,fullname);
            pst.setString(2,username);
            pst.setString(3,password);
            pst.setString(4,role);
            pst.setInt(5,id);

            pst.executeUpdate();
            JOptionPane.showMessageDialog(this,"Admin Updated");

            loadAdminTable();
            loadDeleteTable();
            loadUpdateTable();

        } catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }
    private void importAdminImage() {
    JFileChooser chooser = new JFileChooser();
    chooser.setCurrentDirectory(new File(System.getProperty("user.home"))); // start from home folder

    int result = chooser.showOpenDialog(this);
    if(result == JFileChooser.APPROVE_OPTION){
        File file = chooser.getSelectedFile(); // <-- THIS WORKS NOW
        try {
            FileInputStream fis = new FileInputStream(file);
            int size = (int) file.length();

            int row = jTable3.getSelectedRow(); // which admin to update
            if(row == -1){
                JOptionPane.showMessageDialog(this,"Select admin first!");
                return;
            }
            int adminId = (int) jTable3.getValueAt(row,0);

            Connection con = DBConnection.getConnection();
            String sql = "UPDATE admins SET picture=? WHERE admin_id=?";
            PreparedStatement pst = con.prepareStatement(sql);

            pst.setBinaryStream(1, fis, size);
            pst.setInt(2, adminId);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this,"Image updated successfully!");
            loadAdminImage(adminId); // refresh label

        } catch(Exception e){
            JOptionPane.showMessageDialog(this,"Error: "+e.getMessage());
        }
    }
}
    // ------------------ LOAD ADMIN IMAGE ------------------
    private void loadAdminImage(int adminId) {
        try (Connection con = DBConnection.getConnection()) {
        String sql = "SELECT picture FROM admins WHERE admin_id=?";
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setInt(1, adminId);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            String fileName = rs.getString("picture");
            if(fileName == null || fileName.isEmpty()){
                fileName = "default.png"; // placeholder image kung wala pa
            }

            String imagePath = System.getProperty("user.dir") + "/images/admins/" + fileName;
            File imgFile = new File(imagePath);

            if(imgFile.exists()){
                ImageIcon icon = new ImageIcon(imgFile.getAbsolutePath());
                Image img = icon.getImage().getScaledInstance(
                    ImportImage.getWidth(),
                    ImportImage.getHeight(),
                    Image.SCALE_SMOOTH
                );
                ImportImage.setIcon(new ImageIcon(img));
            } else {
                System.out.println("Image file not found: " + imagePath);
                ImportImage.setIcon(null);
            }
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error loading image: " + e.getMessage());
        e.printStackTrace();
    }
    }
    
    private void Choose_ImageActionPerformed(java.awt.event.ActionEvent evt) {
    JFileChooser chooser = new JFileChooser();
    int option = chooser.showOpenDialog(this);

    if(option == JFileChooser.APPROVE_OPTION){
        previewedImageFile = chooser.getSelectedFile();

        // Ipakita sa white square JLabel
        ImageIcon icon = new ImageIcon(previewedImageFile.getAbsolutePath());
        Image img = icon.getImage().getScaledInstance(
            ImportImage.getWidth(),
            ImportImage.getHeight(),
            Image.SCALE_SMOOTH
        );
        ImportImage.setIcon(new ImageIcon(img));

        // ✅ No success message here, just preview
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        SA_Home = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        ADMIN_ACCOUNT = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        ADMIN_username = new javax.swing.JTextField();
        SELECT_role = new javax.swing.JComboBox<>();
        ADMIN_password = new javax.swing.JPasswordField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        Create_Account = new javax.swing.JButton();
        ADMIN_Fullname = new javax.swing.JTextField();
        ADMIN_email = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        Import_AdminImage = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        ImportImage = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        DELETE_ACCOUNT = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        admintable = new javax.swing.JTable();
        DELETE_account = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        userTable = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        UPDATE_role = new javax.swing.JComboBox<>();
        UPDATEADMIN_username = new javax.swing.JTextField();
        UPDATEADMIN_password = new javax.swing.JPasswordField();
        Update_Account = new javax.swing.JButton();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox6 = new javax.swing.JCheckBox();
        jCheckBox7 = new javax.swing.JCheckBox();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        UPDATEADMIN_Fullname = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jCheckBox4 = new javax.swing.JCheckBox();
        Update_AdminImage = new javax.swing.JButton();
        Updated_Image = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(193, 133, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("MANAGE ACCOUNT");

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/WDSSLOGO.jpg"))); // NOI18N

        SA_Home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/homeIcon (1).png"))); // NOI18N
        SA_Home.setText("jLabel2");
        SA_Home.setPreferredSize(new java.awt.Dimension(64, 63));
        SA_Home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SA_HomeMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(SA_Home, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(SA_Home, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(9, 9, 9)))
                .addContainerGap())
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 204));

        jTabbedPane2.setBackground(new java.awt.Color(193, 133, 0));
        jTabbedPane2.setForeground(new java.awt.Color(255, 255, 255));
        jTabbedPane2.setFont(new java.awt.Font("Serif", 1, 14)); // NOI18N

        ADMIN_ACCOUNT.setBackground(new java.awt.Color(0, 153, 153));
        ADMIN_ACCOUNT.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jTable1.setAutoCreateRowSorter(true);
        jTable1.setBackground(new java.awt.Color(0, 102, 102));
        jTable1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTable1.setForeground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ADMIN ID", "ADMIN NAME", "ADMIN EMAIL", "ADMIN USERNAME", "ADMIN ROLE"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, true, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setGridColor(new java.awt.Color(255, 255, 255));
        jTable1.getTableHeader().setResizingAllowed(false);
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
        }

        jPanel3.setBackground(new java.awt.Color(0, 102, 102));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 204));
        jLabel1.setText("CREATE ADMIN ACCOUNT");

        SELECT_role.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "------SELECT ROLE------", "SUPER_ADMIN", "ADMIN" }));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 204));
        jLabel8.setText("USERNAME :");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 204));
        jLabel9.setText("PASSWORD :");

        Create_Account.setBackground(new java.awt.Color(0, 204, 204));
        Create_Account.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        Create_Account.setForeground(new java.awt.Color(255, 255, 255));
        Create_Account.setText("CREATE ACCOUNT");
        Create_Account.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Create_Account.addActionListener(this::Create_AccountActionPerformed);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 204));
        jLabel12.setText("ADMIN IMAGE :");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 204));
        jLabel13.setText("EMAIL :");

        Import_AdminImage.setBackground(new java.awt.Color(0, 204, 204));
        Import_AdminImage.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        Import_AdminImage.setForeground(new java.awt.Color(255, 255, 255));
        Import_AdminImage.setText("IMPORT IMAGE HERE");
        Import_AdminImage.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Import_AdminImage.addActionListener(this::Import_AdminImageActionPerformed);

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 204));
        jLabel15.setText("FULLNAME :");

        ImportImage.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3));
        ImportImage.setPreferredSize(new java.awt.Dimension(187, 176));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(89, 89, 89)
                        .addComponent(Import_AdminImage, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(103, 103, 103)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ImportImage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 95, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9)
                    .addComponent(jLabel13)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(ADMIN_username)
                    .addComponent(SELECT_role, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ADMIN_password)
                    .addComponent(Create_Account, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ADMIN_Fullname)
                    .addComponent(ADMIN_email, javax.swing.GroupLayout.Alignment.LEADING))
                .addGap(19, 19, 19))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(413, 413, 413)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(226, 226, 226)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SELECT_role, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ADMIN_Fullname, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ADMIN_email, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 18, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(ADMIN_username, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel9)
                                .addGap(34, 34, 34))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(ADMIN_password, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ImportImage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Import_AdminImage, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addComponent(Create_Account, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(127, 127, 127)
                    .addComponent(jLabel15)
                    .addContainerGap(248, Short.MAX_VALUE)))
        );

        jLabel6.setBackground(new java.awt.Color(255, 255, 204));
        jLabel6.setFont(new java.awt.Font("Serif", 3, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 204));
        jLabel6.setText("ADMIN ACCOUNTS");

        javax.swing.GroupLayout ADMIN_ACCOUNTLayout = new javax.swing.GroupLayout(ADMIN_ACCOUNT);
        ADMIN_ACCOUNT.setLayout(ADMIN_ACCOUNTLayout);
        ADMIN_ACCOUNTLayout.setHorizontalGroup(
            ADMIN_ACCOUNTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ADMIN_ACCOUNTLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1001, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
            .addGroup(ADMIN_ACCOUNTLayout.createSequentialGroup()
                .addGap(153, 153, 153)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(ADMIN_ACCOUNTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(ADMIN_ACCOUNTLayout.createSequentialGroup()
                    .addGap(410, 410, 410)
                    .addComponent(jLabel6)
                    .addContainerGap(410, Short.MAX_VALUE)))
        );
        ADMIN_ACCOUNTLayout.setVerticalGroup(
            ADMIN_ACCOUNTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ADMIN_ACCOUNTLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(ADMIN_ACCOUNTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(ADMIN_ACCOUNTLayout.createSequentialGroup()
                    .addGap(323, 323, 323)
                    .addComponent(jLabel6)
                    .addContainerGap(328, Short.MAX_VALUE)))
        );

        jTabbedPane2.addTab("ADMIN ACCOUNT", ADMIN_ACCOUNT);

        DELETE_ACCOUNT.setBackground(new java.awt.Color(102, 0, 0));
        DELETE_ACCOUNT.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        admintable.setBackground(new java.awt.Color(153, 0, 0));
        admintable.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        admintable.setFont(new java.awt.Font("Serif", 1, 12)); // NOI18N
        admintable.setForeground(new java.awt.Color(255, 255, 255));
        admintable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ADMIN ID", "FULLNAME", "USERNAME", "PASSWORD", "ROLE"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, true, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(admintable);
        if (admintable.getColumnModel().getColumnCount() > 0) {
            admintable.getColumnModel().getColumn(0).setResizable(false);
            admintable.getColumnModel().getColumn(1).setResizable(false);
            admintable.getColumnModel().getColumn(2).setResizable(false);
            admintable.getColumnModel().getColumn(3).setResizable(false);
            admintable.getColumnModel().getColumn(4).setResizable(false);
        }

        DELETE_account.setBackground(new java.awt.Color(204, 0, 0));
        DELETE_account.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        DELETE_account.setText("DELETE ACCOUNT");
        DELETE_account.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        DELETE_account.addActionListener(this::DELETE_accountActionPerformed);

        userTable.setBackground(new java.awt.Color(204, 0, 0));
        userTable.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        userTable.setFont(new java.awt.Font("Serif", 1, 12)); // NOI18N
        userTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "USER ID", "FULLNAME", "USERNAME", "PASSWORD", "ROLE"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, true, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(userTable);
        if (userTable.getColumnModel().getColumnCount() > 0) {
            userTable.getColumnModel().getColumn(0).setResizable(false);
            userTable.getColumnModel().getColumn(1).setResizable(false);
            userTable.getColumnModel().getColumn(2).setResizable(false);
            userTable.getColumnModel().getColumn(3).setResizable(false);
            userTable.getColumnModel().getColumn(4).setResizable(false);
        }

        jLabel4.setBackground(new java.awt.Color(255, 255, 204));
        jLabel4.setFont(new java.awt.Font("Serif", 3, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 204));
        jLabel4.setText("CLIENT ACCOUNTS");

        jLabel5.setBackground(new java.awt.Color(255, 255, 204));
        jLabel5.setFont(new java.awt.Font("Serif", 3, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 204));
        jLabel5.setText("ADMIN ACCOUNTS");

        javax.swing.GroupLayout DELETE_ACCOUNTLayout = new javax.swing.GroupLayout(DELETE_ACCOUNT);
        DELETE_ACCOUNT.setLayout(DELETE_ACCOUNTLayout);
        DELETE_ACCOUNTLayout.setHorizontalGroup(
            DELETE_ACCOUNTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DELETE_ACCOUNTLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 485, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, DELETE_ACCOUNTLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(DELETE_account, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(420, 420, 420))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, DELETE_ACCOUNTLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(145, 145, 145))
            .addGroup(DELETE_ACCOUNTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(DELETE_ACCOUNTLayout.createSequentialGroup()
                    .addGap(180, 180, 180)
                    .addComponent(jLabel5)
                    .addContainerGap(640, Short.MAX_VALUE)))
        );
        DELETE_ACCOUNTLayout.setVerticalGroup(
            DELETE_ACCOUNTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DELETE_ACCOUNTLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(DELETE_ACCOUNTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(DELETE_account, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(221, Short.MAX_VALUE))
            .addGroup(DELETE_ACCOUNTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(DELETE_ACCOUNTLayout.createSequentialGroup()
                    .addGap(35, 35, 35)
                    .addComponent(jLabel5)
                    .addContainerGap(616, Short.MAX_VALUE)))
        );

        jTabbedPane2.addTab("DELETE ACCOUNT", DELETE_ACCOUNT);

        jPanel4.setBackground(new java.awt.Color(0, 102, 51));

        jTable3.setBackground(new java.awt.Color(0, 204, 153));
        jTable3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ADMIN ID", "ADMIN ROLE", "ADMIN FULLNAME", "ADMIN USERNAME", "ADMIN PASSWORD"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);
        if (jTable3.getColumnModel().getColumnCount() > 0) {
            jTable3.getColumnModel().getColumn(0).setResizable(false);
            jTable3.getColumnModel().getColumn(0).setPreferredWidth(2);
            jTable3.getColumnModel().getColumn(1).setResizable(false);
            jTable3.getColumnModel().getColumn(2).setResizable(false);
            jTable3.getColumnModel().getColumn(3).setResizable(false);
            jTable3.getColumnModel().getColumn(4).setResizable(false);
        }

        jPanel5.setBackground(new java.awt.Color(0, 204, 153));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3));
        jPanel5.setPreferredSize(new java.awt.Dimension(715, 397));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 204));
        jLabel3.setText("UPDATE ADMIN ACCOUNT");

        UPDATE_role.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "------UPDATE ROLE------", "SUPER_ADMIN", "ADMIN" }));

        Update_Account.setBackground(new java.awt.Color(0, 204, 204));
        Update_Account.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        Update_Account.setForeground(new java.awt.Color(255, 255, 255));
        Update_Account.setText("UPDATE ACCOUNT");
        Update_Account.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Update_Account.addActionListener(this::Update_AccountActionPerformed);

        jCheckBox3.setBackground(new java.awt.Color(0, 204, 153));
        jCheckBox3.setText("Not now");

        jCheckBox6.setBackground(new java.awt.Color(0, 204, 153));
        jCheckBox6.setText("Not now");

        jCheckBox7.setBackground(new java.awt.Color(0, 204, 153));
        jCheckBox7.setText("Not now");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 204));
        jLabel10.setText("USERNAME :");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 204));
        jLabel11.setText("PASSWORD :");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 204));
        jLabel14.setText("FULLNAME :");

        jCheckBox4.setBackground(new java.awt.Color(0, 204, 153));
        jCheckBox4.setText("Not now");

        Update_AdminImage.setBackground(new java.awt.Color(0, 204, 204));
        Update_AdminImage.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        Update_AdminImage.setForeground(new java.awt.Color(255, 255, 255));
        Update_AdminImage.setText("UPDATE IMAGE HERE");
        Update_AdminImage.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Update_AdminImage.addActionListener(this::Update_AdminImageActionPerformed);

        Updated_Image.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3));
        Updated_Image.setPreferredSize(new java.awt.Dimension(187, 176));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 70, Short.MAX_VALUE)
                        .addComponent(jLabel14))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addComponent(Update_AdminImage, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(97, 97, 97)
                        .addComponent(Updated_Image, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox4)
                    .addComponent(jCheckBox3)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(Update_Account, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(UPDATEADMIN_username, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(UPDATE_role, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(UPDATEADMIN_password, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(UPDATEADMIN_Fullname, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addComponent(jCheckBox6)
                    .addComponent(jCheckBox7))
                .addGap(28, 28, 28))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(UPDATEADMIN_Fullname, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(UPDATEADMIN_username, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(UPDATEADMIN_password, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(1, 1, 1)
                .addComponent(jCheckBox6)
                .addGap(18, 18, 18)
                .addComponent(UPDATE_role, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox7)
                .addGap(26, 26, 26)
                .addComponent(Update_Account, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Updated_Image, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(Update_AdminImage, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 983, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(158, 158, 158))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(240, 240, 240))
        );

        jTabbedPane2.addTab("UPDATE ACCOUNT", jPanel4);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1037, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 722, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(233, 233, 233))
        );

        jTabbedPane2.getAccessibleContext().setAccessibleName("tab 1");

        jScrollPane5.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 1078, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 764, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SA_HomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SA_HomeMouseClicked
        SAdminBoard S = new SAdminBoard();
        S.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_SA_HomeMouseClicked

    private void Create_AccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Create_AccountActionPerformed
    String role = SELECT_role.getSelectedItem().toString();
    String fullname = ADMIN_Fullname.getText().trim();
    String email = ADMIN_email.getText().trim();
    String username = ADMIN_username.getText().trim();
    String password = new String(ADMIN_password.getPassword());

    if(role.equals("------SELECT ROLE------") || username.isEmpty() || password.isEmpty()){
        JOptionPane.showMessageDialog(this,"Please fill all fields!");
        return;
    }

    try (Connection conn = DBConnection.getConnection()) {
        // --- INSERT Admin without image first ---
        String sqlInsert = "INSERT INTO admins (full_name,email,username,password,role) VALUES(?,?,?,?,?)";
        PreparedStatement ps = conn.prepareStatement(sqlInsert, Statement.RETURN_GENERATED_KEYS);
        ps.setString(1, fullname);
        ps.setString(2, email);
        ps.setString(3, username);
        ps.setString(4, password);
        ps.setString(5, role);
        ps.executeUpdate();

        // --- Get generated admin_id ---
        ResultSet rs = ps.getGeneratedKeys();
        int adminId = 0;
        if(rs.next()){
            adminId = rs.getInt(1);
        }

        // --- Save image file if selected ---
        if(selectedAdminImageFile != null){
            String destDir = System.getProperty("user.dir") + "/images/admins/";
            File destFile = new File(destDir + selectedAdminImageFile.getName());
            destFile.getParentFile().mkdirs(); // siguraduhing folder exist
            java.nio.file.Files.copy(selectedAdminImageFile.toPath(), destFile.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

            // Update filename sa DB
            String sqlImage = "UPDATE admins SET picture=? WHERE admin_id=?";
            PreparedStatement pstImg = conn.prepareStatement(sqlImage);
            pstImg.setString(1, selectedAdminImageFile.getName());
            pstImg.setInt(2, adminId);
            pstImg.executeUpdate();
        }

        JOptionPane.showMessageDialog(this,"Admin account created successfully!");

        // --- Clear form ---
        ADMIN_username.setText("");
        ADMIN_password.setText("");
        ADMIN_Fullname.setText("");
        SELECT_role.setSelectedIndex(0);
        ImportImage.setIcon(null);
        selectedAdminImageFile = null;

        // --- Refresh Tables and preview ---
        loadAdminTable();
        loadDeleteTable();
        loadUpdateTable();
        loadAdminImage(adminId);

    } catch (Exception e){
        e.printStackTrace();
        JOptionPane.showMessageDialog(this,"Error creating account: "+e.getMessage());
    }
    }//GEN-LAST:event_Create_AccountActionPerformed

    private void DELETE_accountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DELETE_accountActionPerformed
    int row = admintable.getSelectedRow();
    int rowUser = userTable.getSelectedRow();

    try (Connection conn = DBConnection.getConnection()) {

        if (row != -1) {

            int id = (int) admintable.getValueAt(row, 0);

            String sql = "DELETE FROM admins WHERE admin_id=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, id);
            pst.executeUpdate();

        } else if (rowUser != -1) {

            int id = (int) userTable.getValueAt(rowUser, 0);

            String sql = "DELETE FROM users WHERE user_id=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, id);
            pst.executeUpdate();

        } else {
            JOptionPane.showMessageDialog(this, "Select account first!");
            return;
        }

        JOptionPane.showMessageDialog(this, "Account Deleted");

        loadAdminTable();
        loadUserTable();
        loadDeleteTable();
        loadUpdateTable();

    } catch (Exception e) {
        e.printStackTrace();
    }
    }//GEN-LAST:event_DELETE_accountActionPerformed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
    int row = jTable3.getSelectedRow();

    if(row != -1){
        // Kukunin ang admin_id mula sa table
        int adminId = (int) jTable3.getValueAt(row,0);

        // Load image gamit ang adminId
        loadAdminImage(adminId);

        // I-set ang iba pang fields
        UPDATEADMIN_Fullname.setText(jTable3.getValueAt(row,2).toString()); // FULLNAME
        UPDATEADMIN_username.setText(jTable3.getValueAt(row,3).toString()); // USERNAME
        UPDATEADMIN_password.setText(jTable3.getValueAt(row,4).toString()); // PASSWORD
        UPDATE_role.setSelectedItem(jTable3.getValueAt(row,1).toString());   // ROLE
    }
    }//GEN-LAST:event_jTable3MouseClicked

    private void Update_AccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Update_AccountActionPerformed
    int row = jTable3.getSelectedRow();
    if(row == -1){
        JOptionPane.showMessageDialog(this,"Select admin first");
        return;
    }

    int id = (int) jTable3.getValueAt(row,0);

    String fullname = UPDATEADMIN_Fullname.getText();
    String username = UPDATEADMIN_username.getText();
    String password = new String(UPDATEADMIN_password.getPassword());
    String role = UPDATE_role.getSelectedItem().toString();

    if(fullname.isEmpty() || username.isEmpty() || password.isEmpty()){
        JOptionPane.showMessageDialog(this,"Fill all fields!");
        return;
    }

    try(Connection con = DBConnection.getConnection()){

        // UPDATE TEXT FIELDS
        String sql = "UPDATE admins SET full_name=?, username=?, password=?, role=? WHERE admin_id=?";
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setString(1, fullname);
        pst.setString(2, username);
        pst.setString(3, password);
        pst.setString(4, role);
        pst.setInt(5, id);
        pst.executeUpdate();

        // UPDATE IMAGE (kung may preview)
        if(previewedImageFile != null){

            String destDir = System.getProperty("user.dir") + "/images/admins/";
            File destFile = new File(destDir + previewedImageFile.getName());

            destFile.getParentFile().mkdirs();

            java.nio.file.Files.copy(
                previewedImageFile.toPath(),
                destFile.toPath(),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING
            );

            String sqlImage = "UPDATE admins SET picture=? WHERE admin_id=?";
            PreparedStatement pstImg = con.prepareStatement(sqlImage);
            pstImg.setString(1, previewedImageFile.getName());
            pstImg.setInt(2, id);
            pstImg.executeUpdate();

            previewedImageFile = null;
        }

        JOptionPane.showMessageDialog(this,"Admin Updated Successfully");

        loadAdminTable();
        loadDeleteTable();
        loadUpdateTable();

        loadAdminImage(id);

    }catch(Exception e){
        JOptionPane.showMessageDialog(this,e.getMessage());
    }
    }//GEN-LAST:event_Update_AccountActionPerformed

    private void Import_AdminImageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Import_AdminImageActionPerformed
        JFileChooser chooser = new JFileChooser();
        int option = chooser.showOpenDialog(this);

        if(option == JFileChooser.APPROVE_OPTION){
        try {
            selectedAdminImageFile = chooser.getSelectedFile();

            // Preview image sa JLabel
            ImageIcon icon = new ImageIcon(selectedAdminImageFile.getAbsolutePath());
            Image img = icon.getImage().getScaledInstance(
                ImportImage.getWidth(),
                ImportImage.getHeight(),
                Image.SCALE_SMOOTH
            );
            ImportImage.setIcon(new ImageIcon(img));

        } catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error loading image: " + e.getMessage());
        }
        }
    }//GEN-LAST:event_Import_AdminImageActionPerformed

    private void Update_AdminImageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Update_AdminImageActionPerformed
    int row = jTable3.getSelectedRow();
    if(row == -1) {
        JOptionPane.showMessageDialog(this, "Select admin first");
        return;
    }

    JFileChooser chooser = new JFileChooser();
    int option = chooser.showOpenDialog(this);

    if(option == JFileChooser.APPROVE_OPTION){
        previewedImageFile = chooser.getSelectedFile();

        // Preview sa JLabel
        ImageIcon icon = new ImageIcon(previewedImageFile.getAbsolutePath());
        Image img = icon.getImage().getScaledInstance(
            ImportImage.getWidth(),
            ImportImage.getHeight(),
            Image.SCALE_SMOOTH
        );

        Updated_Image.setIcon(new ImageIcon(img));
    }
    }//GEN-LAST:event_Update_AdminImageActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new AccountManage().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ADMIN_ACCOUNT;
    private javax.swing.JTextField ADMIN_Fullname;
    private javax.swing.JTextField ADMIN_email;
    private javax.swing.JPasswordField ADMIN_password;
    private javax.swing.JTextField ADMIN_username;
    private javax.swing.JButton Create_Account;
    private javax.swing.JPanel DELETE_ACCOUNT;
    private javax.swing.JButton DELETE_account;
    private javax.swing.JLabel ImportImage;
    private javax.swing.JButton Import_AdminImage;
    private javax.swing.JLabel SA_Home;
    private javax.swing.JComboBox<String> SELECT_role;
    private javax.swing.JTextField UPDATEADMIN_Fullname;
    private javax.swing.JPasswordField UPDATEADMIN_password;
    private javax.swing.JTextField UPDATEADMIN_username;
    private javax.swing.JComboBox<String> UPDATE_role;
    private javax.swing.JButton Update_Account;
    private javax.swing.JButton Update_AdminImage;
    private javax.swing.JLabel Updated_Image;
    private javax.swing.JTable admintable;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable userTable;
    // End of variables declaration//GEN-END:variables
} 
