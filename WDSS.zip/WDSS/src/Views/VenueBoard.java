/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Views;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import DBconnector.DBConnection;
import Views.Session;

public class VenueBoard extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VenueBoard.class.getName());
    
    private int userId; // kung gagamitin mo pa sa booking
    
    public VenueBoard(int userId) {
        this.userId = userId;
        initComponents();
        loadVenues();
        // default selection
        if (venueOPT.getItemCount() > 0) {
            venueOPT.setSelectedIndex(0);
            updateVenueDetails((String) venueOPT.getSelectedItem());
        }
    }
    private void loadUserData() {
        int currentUserId = Session.loggedInUserId;
        if (currentUserId <= 0) {
            JOptionPane.showMessageDialog(this, "No user is currently logged in!");
            return;
        }
    }

    public VenueBoard() {
        initComponents();
        loadVenues();
        if (venueOPT.getItemCount() > 0) {
            venueOPT.setSelectedIndex(0);
            updateVenueDetails((String) venueOPT.getSelectedItem());
        }
    }

    /** Load available venues from DB */
    private void loadVenues() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT venue_name FROM venues WHERE status='AVAILABLE' AND visible=1";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
            while (rs.next()) {
                model.addElement(rs.getString("venue_name"));
            }
            venueOPT.setModel(model);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading venues: " + ex.getMessage());
            logger.severe("DB Load Venue Error: " + ex.getMessage());
        }
    }

    /** Update labels and image for selected venue */
    private void updateVenueDetails(String venue) {
        if (venue == null) return;

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT venue_name, capacity, price FROM venues WHERE venue_name = ? AND status='AVAILABLE' AND visible=1";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, venue);
            ResultSet rs = pst.executeQuery();

            if(rs.next()) {
                VenueType.setText("VENUE TYPE: " + rs.getString("venue_name"));
                CapacityType.setText("CAPACITY: " + rs.getInt("capacity") + " guests");
                PriceRangeType.setText(String.format("PRICE: ₱%,.0f", rs.getDouble("price")));
            } else {
                VenueType.setText("VENUE TYPE: " + venue);
                CapacityType.setText("CAPACITY: TBD");
                PriceRangeType.setText("PRICE: TBD");
            }

        } catch(SQLException e) {
            System.err.println("Error fetching venue info: " + e.getMessage());
            VenueType.setText("VENUE TYPE: " + venue);
            CapacityType.setText("CAPACITY: TBD");
            PriceRangeType.setText("PRICE: TBD");
        }

        // load image
        String imagePath = getVenueImagePathFromDB(venue);
        setVenueImage(imagePath);
    }

    private String getVenueImagePathFromDB(String venueName) {
        String path = null;
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT image_path FROM venues WHERE venue_name = ? AND status='AVAILABLE' AND visible=1";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, venueName);
            ResultSet rs = pst.executeQuery();
            if(rs.next()) path = rs.getString("image_path");
        } catch(Exception e) {
            System.err.println("Error fetching image path: " + e.getMessage());
        }
        return path;
    }

    private void setVenueImage(String path) {
        java.awt.Image img = null;
        if(path != null && !path.isEmpty() && new java.io.File(path).exists()) {
            img = new ImageIcon(path).getImage();
        } else {
            java.net.URL defaultImg = getClass().getResource("/Images/defaultVenue.jpg");
            if(defaultImg != null) img = new ImageIcon(defaultImg).getImage();
        }

        if(img != null) {
            img = img.getScaledInstance(VenueImage.getWidth(), VenueImage.getHeight(), java.awt.Image.SCALE_SMOOTH);
            VenueImage.setIcon(new ImageIcon(img));
        } else {
            VenueImage.setIcon(null);
            VenueImage.setText("No image available");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        SA_Home2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        SA_Home = new javax.swing.JLabel();
        SA_Home1 = new javax.swing.JLabel();
        venueOPT = new javax.swing.JComboBox<>();
        VenueType = new javax.swing.JLabel();
        CapacityType = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        VenueImage = new javax.swing.JLabel();
        PriceRangeType = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 204));

        jPanel2.setBackground(new java.awt.Color(193, 133, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("VOW VISTA");

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/WDSSLOGO.jpg"))); // NOI18N

        SA_Home2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/homeIcon (1).png"))); // NOI18N
        SA_Home2.setText("jLabel2");
        SA_Home2.setPreferredSize(new java.awt.Dimension(64, 63));
        SA_Home2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SA_Home2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(234, 234, 234)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 348, Short.MAX_VALUE)
                .addComponent(SA_Home2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(SA_Home2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addGap(10, 10, 10))))
                .addContainerGap())
        );

        jLabel5.setFont(new java.awt.Font("Serif", 1, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(193, 133, 0));
        jLabel5.setText("CHOOSE YOUR DECIDED VENUE TYPE");

        SA_Home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/homeIcon (1).png"))); // NOI18N
        SA_Home.setText("jLabel2");
        SA_Home.setPreferredSize(new java.awt.Dimension(64, 63));

        SA_Home1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/homeIcon (1).png"))); // NOI18N
        SA_Home1.setText("jLabel2");
        SA_Home1.setPreferredSize(new java.awt.Dimension(64, 63));

        venueOPT.setBackground(new java.awt.Color(255, 255, 204));
        venueOPT.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        venueOPT.setForeground(new java.awt.Color(193, 133, 0));
        venueOPT.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(193, 133, 0), 3, true));
        venueOPT.addActionListener(this::venueOPTActionPerformed);

        VenueType.setFont(new java.awt.Font("Serif", 1, 20)); // NOI18N
        VenueType.setForeground(new java.awt.Color(193, 133, 0));
        VenueType.setText("VENUE TYPE:");

        CapacityType.setFont(new java.awt.Font("Serif", 1, 20)); // NOI18N
        CapacityType.setForeground(new java.awt.Color(193, 133, 0));
        CapacityType.setText("CAPACITY:");

        jLabel10.setFont(new java.awt.Font("Serif", 1, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(193, 133, 0));
        jLabel10.setText("PRICE RANGE:");

        jLabel11.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(193, 133, 0));
        jLabel11.setText("CLICK TO CHOOSE");

        VenueImage.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        VenueImage.setPreferredSize(new java.awt.Dimension(224, 304));
        VenueImage.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VenueImageMouseClicked(evt);
            }
        });

        PriceRangeType.setFont(new java.awt.Font("Serif", 1, 20)); // NOI18N
        PriceRangeType.setForeground(new java.awt.Color(193, 133, 0));
        PriceRangeType.setText("PRICE RANGE:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(1413, 1413, 1413)
                        .addComponent(jLabel3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addComponent(jLabel11)
                        .addGap(127, 127, 127)
                        .addComponent(venueOPT, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(305, 305, 305)
                        .addComponent(jLabel5))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(142, 142, 142)
                                .addComponent(jLabel8)
                                .addGap(136, 136, 136))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(VenueImage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CapacityType)
                            .addComponent(VenueType)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jLabel10))
                            .addComponent(PriceRangeType))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(SA_Home, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(SA_Home1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(venueOPT, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(104, 104, 104)
                        .addComponent(VenueType)
                        .addGap(42, 42, 42)
                        .addComponent(CapacityType)
                        .addGap(39, 39, 39)
                        .addComponent(PriceRangeType)
                        .addGap(328, 328, 328)
                        .addComponent(jLabel10))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(VenueImage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(145, 145, 145)
                .addComponent(jLabel8)
                .addGap(2358, 2358, 2358)
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(SA_Home, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(SA_Home1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 1006, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 571, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SA_Home2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SA_Home2MouseClicked
        ClientBoard C = new ClientBoard();
        C.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_SA_Home2MouseClicked

    private void venueOPTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_venueOPTActionPerformed
        updateVenueDetails((String) venueOPT.getSelectedItem());
    }//GEN-LAST:event_venueOPTActionPerformed

    private void VenueImageMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VenueImageMouseClicked
    String selectedVenue = (String) venueOPT.getSelectedItem();
    if (selectedVenue == null || selectedVenue.isEmpty()) return;

    try (Connection conn = DBConnection.getConnection()) {
        String sql = "SELECT venue_id, venue_name, capacity, price FROM venues WHERE venue_name = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, selectedVenue);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            int venueId = rs.getInt("venue_id");
            String name = rs.getString("venue_name");
            int capacity = rs.getInt("capacity");
            double price = rs.getDouble("price");

            // **Create single instance and show it**
            VenueDetails vd = new VenueDetails(Session.loggedInUserId
            ,Session.loggedInUsername);
            vd.setVenueDetails(venueId, name, capacity, price);
            vd.setVisible(true);  // visible na dito
            this.dispose();       // close VenueBoard
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error opening venue details: " + e.getMessage());
    }
    }//GEN-LAST:event_VenueImageMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new VenueBoard().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel CapacityType;
    private javax.swing.JLabel PriceRangeType;
    private javax.swing.JLabel SA_Home;
    private javax.swing.JLabel SA_Home1;
    private javax.swing.JLabel SA_Home2;
    private javax.swing.JLabel VenueImage;
    private javax.swing.JLabel VenueType;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JComboBox<String> venueOPT;
    // End of variables declaration//GEN-END:variables
}
