/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Views;

/**
 *
 * @author annie
 */
public class Session {
    public static int loggedInUserId = -1;   // -1 = no one logged in
    public static String loggedInUsername = "";
    
    public static int loggedInAdminId = -1;      // -1 = nobody logged in
    public static String loggedInAdminName = ""; // admin name
    public static String loggedInAdminPic = "";
}
