/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Models.Users;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import DBconnector.DBConnection;
import java.sql.ResultSet;

public class UserController {
    // 1️⃣ Register user
    public boolean registerUser(Users user) {
        String sql = "INSERT INTO users(full_name, email, username, password, role) VALUES (?, ?, ?, ?,'CLIENT')";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getFullName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getUsername());
            ps.setString(4, user.getPassword());

            int rowsInserted = ps.executeUpdate();
            return rowsInserted > 0; // return true if inserted

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 2️⃣ Check for duplicate email or username
    public boolean checkDuplicate(String email, String username) {
        boolean exists = false;
        String sql = "SELECT * FROM users WHERE email = ? OR username = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, username);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                exists = true; // email or username already exists
            }

            rs.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exists;
    }

    // 3️⃣ Convert / encrypt password
    public String convert(String input, String[] keyMap, String[] refMap) {
        StringBuilder result = new StringBuilder();
        for (char c : input.toCharArray()) {
            int index = -1;
            for (int i = 0; i < refMap.length; i++) {
                if (refMap[i].charAt(0) == c) {
                    index = i;
                    break;
                }
            }
            result.append(index != -1 ? keyMap[index] : c);
        }
        return result.toString();
    }

    // 4️⃣ Verify duplicate for older code (optional, can use checkDuplicate instead)
    public boolean verify(String email, String username) { 
        boolean duplicate = false;
        String sql = "SELECT * FROM users"; 
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                if (email.equals(rs.getString("email")) || username.equals(rs.getString("username"))) {
                    duplicate = true;
                    break;
                }
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return duplicate;
    }
    
    public boolean changePassword(String username, String oldPass, String newPass) {

    String sqlCheck = "SELECT password FROM users WHERE username = ?";
    String sqlUpdate = "UPDATE users SET password = ? WHERE username = ?";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement psCheck = conn.prepareStatement(sqlCheck)) {

        psCheck.setString(1, username);
        ResultSet rs = psCheck.executeQuery();

        if(rs.next()){

            String dbPassword = rs.getString("password");

            String[] small = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".split("");

            String[] encrypt1 = {"b","s","a","y","w","x","7","f","n","C","r","B","3","F","D","L","Y","O","c","E","J","d","q","g","t","l","K","e","T","H","M","m","2","S","5","p","1","R","0","A","X","k","V","i","P","h","G","W","4","8","9","6","j","o","U","I","v","Q","z","Z","N","u"};       

            String[] encrypt2 = {"i","Q","2","m","B","h","t","E","S","x","L","n","0","J","d","7","I","K","v","R","a","N","8","f","k","P","V","3","w","y","c","4","g","M","O","G","o","1","p","z","u","Y","s","b","W","U","T","l","5","H","F","e","A","D","q","j","9","Z","C","X","6","r"};    

            String[] encrypt3 = {"G","p","8","V","k","y","z","P","2","S","r","f","c","I","0","L","d","X","n","M","w","t","v","O","J","q","A","B","1","u","6","E","4","h","Z","m","H","i","R","g","K","l","Q","N","a","o","x","7","W","U","Y","s","j","3","C","T","e","5","D","F","9","b"};

            String encryptedOld = convert(oldPass, encrypt1, small);
            encryptedOld = convert(encryptedOld, encrypt2, encrypt1);
            encryptedOld = convert(encryptedOld, encrypt3, encrypt2);

            if(!encryptedOld.equals(dbPassword)){
                return false;
            }

            String encryptedNew = convert(newPass, encrypt1, small);
            encryptedNew = convert(encryptedNew, encrypt2, encrypt1);
            encryptedNew = convert(encryptedNew, encrypt3, encrypt2);

            try(PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate)){
                psUpdate.setString(1, encryptedNew);
                psUpdate.setString(2, username);

                return psUpdate.executeUpdate() > 0;
            }
        }

    } catch(Exception e){
        e.printStackTrace();
    }

    return false;
}
    
}

       
   
